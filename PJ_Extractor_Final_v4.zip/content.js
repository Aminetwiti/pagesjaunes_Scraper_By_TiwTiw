// Ce script ne fait rien pour l’instant, tout est déclenché via popup.js
