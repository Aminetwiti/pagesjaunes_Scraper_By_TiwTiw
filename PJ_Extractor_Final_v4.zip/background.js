// Service worker minimal (obligatoire pour MV3)
